<template>
  <div class="lab-group">
    <h3>Lab Tabels with thier view of content</h3>
    <!-- <router-view /> -->
  </div>
</template>

<script>

</script>
