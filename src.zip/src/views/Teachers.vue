<template>
  <h1>Teachers Page</h1>
</template>
