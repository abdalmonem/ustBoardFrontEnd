<template>
  <div class="lect-group">
    <h3>Lect Tabels with thier view of content</h3>
    <app-tabels-form></app-tabels-form>
    <router-view />
  </div>
</template>

<script>

export default {
};

</script>
