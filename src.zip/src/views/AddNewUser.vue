<template>
  kk
</template>

<script>

export default {
};

</script>

<style scoped>
.x{
  color: #000;
}
</style>
