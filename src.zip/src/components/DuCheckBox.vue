<template>
  <div class="check-box">
    <input type="checkbox" />
  </div>
</template>

<script>

export default {
  name: 'DuCheckBox',
};

</script>

<style scoped>

</style>
